import { Pipe, PipeTransform} from '@angular/core'

@Pipe({name: 'titlecase'})
export class TitleCasePipe implements PipeTransform {
  transform(value: string): string {
    // linku i zgjidhjes : https://www.freecodecamp.org/news/three-ways-to-title-case-a-sentence-in-javascript-676a9175eb27/
    value = value.toLowerCase();
    
    value=value.split(' ');
    
    for(var i=0; i < value.length; i++) {
      value[i] = value[i].charAt(0).toUpperCase() + value[i].slice(1);
    }
    return value.join(' ')
  }
}