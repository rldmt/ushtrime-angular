var primeCalc = {
  calculatePrime: function() {
    return 5;
  }
}