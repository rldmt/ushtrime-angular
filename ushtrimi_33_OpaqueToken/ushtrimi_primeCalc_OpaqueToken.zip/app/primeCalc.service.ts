import { OpaqueToken } from '@angular/core';

export let PRIME_CALC_TOKEN = new OpaqueToken('primeCalc');