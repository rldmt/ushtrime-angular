# Use Opaque Token & @Inject (Finished)
### [Angular 2 Fundamentals]("https://app.pluralsight.com/courses/angular2-fundamentals") Practice Exercise

**_Instructions_**: This is the finished version of the practice exercise that is
available here: http://plnkr.co/edit/HZpkFy3ND3GmY2YbiFG7?p=info. To try the exercise
go there for further instructions.
