import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
    <event-erialdo></event-erialdo>
  `,
})
export class AppComponent {
}
