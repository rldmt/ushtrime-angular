import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
    <event-details></event-details>
  `,
})
export class AppComponent {
}
