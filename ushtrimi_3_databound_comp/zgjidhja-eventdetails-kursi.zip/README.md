# Creating a Data-bound Component
### [Angular 2 Fundamentals](https://app.pluralsight.com/courses/angular2-fundamentals) Practice Exercise

**_Instructions_**: This is the finished version of the practice exercise that is
available here: https://plnkr.co/edit/K5VCArHCCMp6md3R6EPn?p=info. To try the exercise
go there for further instructions