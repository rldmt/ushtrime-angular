import { Component } from '@angular/core';

@Component({
  selector: 'closable-well',
  template: `
    <div class="well" *ngIf="shfaq">
      <ng-content></ng-content>
      <button class="btn btn-primary" (click)="mbyll()">mbyll</button>
    </div>
  `
})
export class ClosableWellComponent {
  shfaq:boolean = true;

  mbyll() {
    this.shfaq = !this.shfaq;
  }
}