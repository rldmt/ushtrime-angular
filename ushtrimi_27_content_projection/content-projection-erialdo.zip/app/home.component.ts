import { Component } from '@angular/core';

@Component({
  selector: 'my-home',
  template: `
  <closable-well>
    <h4>This is some content that can be hidden</h4>
  </closable-well>
  `
})
export class HomeComponent implements OnInit {


  constructor() {
  }

}

