import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'my-app',
  template: `
    <parent></parent>
  `,
})
export class AppComponent {
}
