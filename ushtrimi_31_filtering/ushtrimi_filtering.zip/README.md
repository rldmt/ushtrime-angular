# Filter a list of movies by their ratingk (Finished)
### [Angular 2 Fundamentals]("https://app.pluralsight.com/courses/angular2-fundamentals") Practice Exercise

**_Instructions_**: This is the finished version of the practice exercise that is
available here: http://plnkr.co/edit/deM5uBUgkHgxE62PguYG?p=info. To try the exercise
go there for further instructions.
