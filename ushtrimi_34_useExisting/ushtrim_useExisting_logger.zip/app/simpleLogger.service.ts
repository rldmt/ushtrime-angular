import { Injectable } from '@angular/core';

@Injectable()
export class SimpleLoggerService {
  logMessage(msg) {
    // not implemented
  }
  
  logError(msg) {
    // not implemented
  }
}