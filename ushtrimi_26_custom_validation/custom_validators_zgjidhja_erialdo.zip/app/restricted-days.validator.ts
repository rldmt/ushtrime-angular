import { FormControl } from '@angular/forms'

export function restrictedDays(days) {
    return (control: FormControl): { [key: string]: any } => {
        if (!days) return null

        var invalidDays = days
            .map(d => getDay(control.value) == d ? d : null)
            .filter(d => d != null)
        return invalidDays && invalidDays.length > 0
            ? { 'restrictedDays': invalidDays.join(',') }
            : null
    }
}

function getDay(date) {
    var numberOfWeekDay = new Date(date).getDay();

    if (/^([0-9]{4})$/.test(new Date(date).getFullYear())) {
        console.log('uu ' + new Date(date).getFullYear())

        var weekday = ['Diele', 'Hene', 'Marte', 'Merkure', 'Enjte', 'Premte', 'Shtune'];

        console.log(weekday[numberOfWeekDay] + ' ===> ' + date + ' ==> ' + new Date(date).getFullYear())
        return weekday[numberOfWeekDay];
    }
    return null
}