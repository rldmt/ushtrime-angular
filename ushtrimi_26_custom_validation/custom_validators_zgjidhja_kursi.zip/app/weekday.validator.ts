import { FormControl } from '@angular/forms'

export function requireWeekday(control: FormControl): {[key: string]: any} {
  let date = new Date(control.value)
  if (isNaN(date)) return null
  
  let dayOfWeek = date.getDay()
  if (dayOfWeek === 6) 
    return {'requireWeekday': 'Must not be a Saturday'}

  if (dayOfWeek === 0) 
    return {'requireWeekday': 'Must not be a Sunday'}

  return null
}